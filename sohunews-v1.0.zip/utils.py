import hashlib
import time
from datetime import date

import simplejson as json
import urllib.request
import urllib.parse

import json


# 获取当前时间
def getNowDateTime():
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())


# 获取当前时间戳
def getTimeStamp():
    return time.localtime()


# 时间戳转日期
def timeStampFormat(timeStamp):
    return date.fromtimestamp(timeStamp)


# 结果类
def result(code, d={}):
    data = dict()
    data['code'] = code
    data['data'] = d
    return json.dumps(data, ensure_ascii=False)


# 将数据以文件形式保存下来
def down_data(page, content):
    with open('搜狐时政_' + str(page) + '.json', 'w', encoding='utf-8') as fp:
        fp.write(content)


def getNews(page):
    url = 'https://cis.sohu.com/cisv4/feeds'
    # url = "https://cis.sohu.com/cisv3/feeds"
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.159 Safari/537.36',
        "Cookie": "gidinf=x099980109ee1753ad15e1858000784d6b0cd49b1d1e; SUV=230717174934U5QG; IPLOC=CN; clt=1696685476; cld=20231007213116; reqtype=pc; t=1696685493506",
        "Content-Type": "application/json;charset=utf-8"
    }
    param = {
        'clientType': 3,
        'pvId': '1696675166609_Rv9TnyW',
        'resourceParam': [
            {
                "requestId": "1696686686702_23071717493_Nt2",
                'resourceId': '1001563447688888320',
                'page': page,
                'size': 20,
                'spm': 'smpc.channel_114.block3_77_O0F7zf_1_fd',
                'context': {
                    'feedType': "XTOPIC_SYNTHETICAL",
                    'pro': '0,1'
                },
                'productParam': {
                    'productId': 438647,
                    'productType': 15,
                    'categoryId': 47,
                    'mediaId': 1
                },
                'resProductParam': {
                    'adTags': '20000111',
                    'productId': 1523,
                    'productType': 13
                },
                'expParam': {},
            }
        ],
        'suv': '1690177869726ceuoqp'
    }
    # post请求的参数 必须要进行编码
    param = json.dumps(param).encode('utf-8')
    requ = urllib.request.Request(url=url, data=param, headers=headers)
    # 模拟浏览器向服务器发送请求
    response = urllib.request.urlopen(requ)
    # return response
    # 获取响应的数据
    content = response.read().decode('utf-8')
    # return content
    # 将获取到的json字符串转成字典返回
    json_loads = json.loads(content)
    dic = json_loads['1001563447688888320']
    # print(dic)
    # print(type(dic))
    return dic


# def getNewsObjDict(content):
#     dic = json.loads(content)
#     dic = dic['1001563447688888320']
#     return dic


# if __name__ == '__main__':
    # stamp_format = timeStampFormat(1697337379)
    # print(stamp_format)
    # print('--------------------------')
    # page = 1
    # news = getNews(page=page)
    # news_dict = getNewsObjDict(news)
    # for key, values in news_dict.items():
    #     print(f"key={key}---------values={values},\n")
    # pass