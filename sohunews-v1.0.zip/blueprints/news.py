from flask import Blueprint

from app import db
from utils import getNews
from models import BriefNewsModel

bp = Blueprint("news", __name__, url_prefix='/news')


def newsDataPack(brief_news, resourceData):
    contentData = resourceData['contentData']
    brief_news.id = resourceData['id']
    brief_news.post_time = contentData['postTime']
    # brief_news.cover_img = contentData['templateInfo']['url']
    # brief_news.cover_height = contentData['templateInfo']['imgHeight']
    # brief_news.cover_width = contentData['templateInfo']['imgWidth']

    brief_news.brief = contentData['brief']
    brief_news.author_id = contentData['authorId']
    brief_news.author_name = contentData['authorName']
    brief_news.author_cover = contentData['authorCover']
    brief_news.author_home_page = contentData['authorHomePage']
    brief_news.title = contentData['title']
    brief_news.excerpt = contentData['excerpt']
    brief_news.url = 'https://www.sohu.com' + contentData['url']
    return brief_news


# todo：每次应先查询每条新闻是否已存在于数据库中，若存在，则不应插入数据库
@bp.route('/insert')
def hello_world():  # put application's code here
    page = 1
    news_dict = getNews(page=page)
    count = news_dict['count']
    data = news_dict['data']
    brief_news_list = []
    for index in range(count):
        i_data = data[index]
        type_ = i_data['resourceType']
        brief_news = BriefNewsModel()
        resourceData = None
        if type_ == 1:
            resourceData = i_data['resourceData']
        else:
            resourceData = i_data['backupContent']['resourceData']
        # 封装数据
        brief_news = newsDataPack(brief_news, resourceData)
        # 插入列表中
        brief_news_list.append(brief_news)
    # for brief_news in brief_news_list:
    #     print(str(brief_news))
    #     db.session.add(brief_news)
    # 插入数据库
    db.session.add_all(brief_news_list)
    db.session.commit()
    return "Insert successful！！！"
